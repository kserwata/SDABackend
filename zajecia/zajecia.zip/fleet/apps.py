from django.apps import AppConfig


class FleetConfig(AppConfig):
    name = 'fleet'
